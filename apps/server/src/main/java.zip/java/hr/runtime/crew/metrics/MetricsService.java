package hr.runtime.crew.metrics;

import hr.runtime.crew.employee.model.entity.Employee;
import hr.runtime.crew.employee.repository.EmployeeRepository;
import hr.runtime.crew.employee.model.enums.WeekDay;
import hr.runtime.crew.employee.dto.WorkSchedule;
import hr.runtime.crew.event.model.enums.EventStatus;
import hr.runtime.crew.event.model.enums.EventType;
import hr.runtime.crew.event.model.entity.WorkEvent;
import hr.runtime.crew.event.model.entity.WorkEventParticipant;
import hr.runtime.crew.event.repository.WorkEventParticipantRepository;
import org.springframework.stereotype.Service;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.time.Duration;
import java.time.LocalDate;

@Service
public class MetricsService {
    private final EmployeeRepository employeeRepository;
    private final WorkEventParticipantRepository participantRepository;
    private static final int MAX_ALLOWED_DAYS = 90;
    private static final int DEFAULT_SWITCH_PENALTY_MINUTES = 15;
    private static final int DEFAULT_FOCUS_TASK_MINUTES = 30;

    public MetricsService(
            EmployeeRepository employeeRepository,
            WorkEventParticipantRepository participantRepository
    ) {
        this.employeeRepository = employeeRepository;
        this.participantRepository = participantRepository;
    }

    public float workingTimeConflict(Long employeeId) {
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        List<WorkEventParticipant> participants =
                participantRepository.findByEmployee_Id(employeeId);

        List<WorkEvent> meetings = participants.stream()
                .map(WorkEventParticipant::getEvent)
                .filter(event -> event.getEventType() == EventType.MEETING)
                .filter(event -> event.getStatus() != EventStatus.CANCELLED)
                .toList();

        int totalMeetings = meetings.size();

        if (totalMeetings == 0) {
            return 0;
        }

        WorkSchedule schedule = employee.getWorkSchedule();

        if (schedule == null) {
            return 1;
        }

        int outsideWorkingTimeCount = 0;

        for (WorkEvent meeting : meetings) {
            if (!isMeetingInsideWorkingTime(meeting, schedule)) {
                outsideWorkingTimeCount++;
            }
        }

        return (float) outsideWorkingTimeCount / totalMeetings;
    }

    private boolean isMeetingInsideWorkingTime(WorkEvent meeting, WorkSchedule schedule) {
        if (schedule.getTimezone() == null
                || schedule.getStartTime() == null
                || schedule.getEndTime() == null
                || schedule.getWorkingDays() == null
                || schedule.getWorkingDays().isEmpty()) {
            return false;
        }

        ZoneId zoneId = ZoneId.of(schedule.getTimezone());

        ZonedDateTime localStart = meeting.getStartAt().atZone(zoneId);
        ZonedDateTime localEnd = meeting.getEndAt().atZone(zoneId);

        if (!localStart.toLocalDate().equals(localEnd.toLocalDate())) {
            return false;
        }

        WeekDay meetingDay = toWeekDay(localStart.getDayOfWeek());

        if (!schedule.getWorkingDays().contains(meetingDay)) {
            return false;
        }

        LocalTime meetingStartTime = localStart.toLocalTime();
        LocalTime meetingEndTime = localEnd.toLocalTime();

        return !meetingStartTime.isBefore(schedule.getStartTime())
                && !meetingEndTime.isAfter(schedule.getEndTime());
    }

    private WeekDay toWeekDay(DayOfWeek dayOfWeek) {
        return switch (dayOfWeek) {
            case MONDAY -> WeekDay.MON;
            case TUESDAY -> WeekDay.TUE;
            case WEDNESDAY -> WeekDay.WED;
            case THURSDAY -> WeekDay.THU;
            case FRIDAY -> WeekDay.FRI;
            case SATURDAY -> WeekDay.SAT;
            case SUNDAY -> WeekDay.SUN;
        };
    }

    public float scheduleActuality(
            Long employeeId,
            Instant scheduleUpdatedAt,
            boolean triggerEventOccurred
    ) {
        if (triggerEventOccurred) {
            return 0;
        }

        if (scheduleUpdatedAt == null) {
            return 0;
        }

        long daysAfterUpdate = ChronoUnit.DAYS.between(scheduleUpdatedAt, Instant.now());

        if (daysAfterUpdate < 0) {
            daysAfterUpdate = 0;
        }

        float conflictCoefficient = workingTimeConflict(employeeId);

        float actuality = 1 - ((float) daysAfterUpdate / MAX_ALLOWED_DAYS) * (1 + conflictCoefficient);

        if (actuality < 0) {
            return 0;
        }

        if (actuality > 1) {
            return 1;
        }

        return actuality;
    }

    public float overloadScore(Long employeeId, LocalDate date) {
        return overloadScore(
                employeeId,
                date,
                DEFAULT_SWITCH_PENALTY_MINUTES,
                DEFAULT_FOCUS_TASK_MINUTES
        );
    }

    public float overloadScore(
            Long employeeId,
            LocalDate date,
            int switchPenaltyMinutes,
            int focusTaskMinutes
    ) {
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        WorkSchedule schedule = employee.getWorkSchedule();

        if (schedule == null
                || schedule.getTimezone() == null
                || schedule.getStartTime() == null
                || schedule.getEndTime() == null) {
            return 1;
        }

        long workMinutes = Duration.between(
                schedule.getStartTime(),
                schedule.getEndTime()
        ).toMinutes();

        if (workMinutes <= 0) {
            return 1;
        }

        ZoneId zoneId = ZoneId.of(schedule.getTimezone());

        List<WorkEventParticipant> participants =
                participantRepository.findByEmployee_Id(employeeId);

        List<WorkEvent> meetings = participants.stream()
                .map(WorkEventParticipant::getEvent)
                .filter(event -> event.getEventType() == EventType.MEETING)
                .filter(event -> event.getStatus() != EventStatus.CANCELLED)
                .filter(event -> isEventOnDate(event, date, zoneId))
                .toList();

        int meetingsCount = meetings.size();

        if (meetingsCount == 0) {
            return 0;
        }

        long busyMinutes = 0;

        for (WorkEvent meeting : meetings) {
            ZonedDateTime start = meeting.getStartAt().atZone(zoneId);
            ZonedDateTime end = meeting.getEndAt().atZone(zoneId);

            busyMinutes += Duration.between(start, end).toMinutes();
        }

        if (busyMinutes >= workMinutes) {
            return 1;
        }

        float freeMinutes = workMinutes - busyMinutes;

        float timePenalty = meetingsCount * switchPenaltyMinutes
                * (1 + (meetingsCount * focusTaskMinutes) / freeMinutes);

        float overload = (busyMinutes + timePenalty) / workMinutes;

        if (overload < 0) {
            return 0;
        }

        if (overload > 1) {
            return 1;
        }

        return overload;
    }

    private boolean isEventOnDate(WorkEvent event, LocalDate date, ZoneId zoneId) {
        LocalDate eventDate = event.getStartAt()
                .atZone(zoneId)
                .toLocalDate();

        return eventDate.equals(date);
    }
}
